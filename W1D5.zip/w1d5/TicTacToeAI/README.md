# w1d5: [TicTacToe AI][description]

[description]: https://github.com/appacademy/ruby-curriculum/blob/master/projects/w1d4-tic-tac-toe-ai.md
